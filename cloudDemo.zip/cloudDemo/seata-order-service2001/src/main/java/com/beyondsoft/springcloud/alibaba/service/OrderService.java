package com.beyondsoft.springcloud.alibaba.service;


import com.beyondsoft.springcloud.alibaba.domain.Order;

public interface OrderService {
    void create(Order order);
}
