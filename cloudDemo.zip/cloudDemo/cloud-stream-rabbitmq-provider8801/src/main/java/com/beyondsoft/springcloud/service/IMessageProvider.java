package com.beyondsoft.springcloud.service;

public interface IMessageProvider {
    public String send();
}
