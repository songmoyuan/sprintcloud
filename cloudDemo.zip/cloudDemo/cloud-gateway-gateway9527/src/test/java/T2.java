import java.time.ZonedDateTime;

public class T2 {
    public static void main(String[] args) {
        ZonedDateTime zbj = ZonedDateTime.now();
        System.out.println(zbj);
        //2021-12-06T17:29:15.228+08:00[Asia/Shanghai]
    }
}
